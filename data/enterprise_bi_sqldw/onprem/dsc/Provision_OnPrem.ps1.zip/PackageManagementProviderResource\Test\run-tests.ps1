cd "$PSScriptRoot"
invoke-pester
