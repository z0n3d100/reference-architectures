# Description

This resource allows you to enforce global permissions in a PWA site for a
specific project server group or an individual resource.
